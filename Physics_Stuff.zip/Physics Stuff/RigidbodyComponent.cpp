#include "Main.h"


void RigidbodyComponent::setForce(Vec2 & force)
{
	m_force = force;
}

