#include "Main.h"

ColliderComponent::ColliderComponent()
{
}


ColliderComponent::~ColliderComponent()
{
}
